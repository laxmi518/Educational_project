package TypeChecker;

import Utilities.Visitor;
import Utilities.SymbolTable;

public class TypeChecker extends Visitor {
    // Intentionally left blank - content will appear in phase 4 handout
    public TypeChecker(SymbolTable classTable, boolean debug) { 
    }
}
