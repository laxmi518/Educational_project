import Io2;

public class System2 {
    static Io2 out;
    static Io2 in;
    static void exit() { }
}