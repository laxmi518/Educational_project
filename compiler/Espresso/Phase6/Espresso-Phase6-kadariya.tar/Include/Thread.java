public class Thread {
    public Thread() { }
    public Thread(Runnable r) { }
    public void run() { }
    public final void start() { }
    public static void sleep(long millis) { }
}
