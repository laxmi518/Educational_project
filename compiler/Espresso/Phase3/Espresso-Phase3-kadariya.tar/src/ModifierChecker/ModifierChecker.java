package ModifierChecker;

import Utilities.Visitor;
import Utilities.SymbolTable;

public class ModifierChecker extends Visitor {
    // Intentionally left blank - content will appear in phase 5 handout
    public ModifierChecker(SymbolTable classTable, boolean debug) {
    }
}
